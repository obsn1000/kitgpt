# 📄 CHANGELOG

All notable changes to this project will be documented in this file.

---

## [v1.0.0] - 2024-04-21

🎉 **Initial stable release after full repo merge**

### Added
- Merged [`square`](https://github.com/obsn1000/square) into [`ApplePayFinal`](https://github.com/obsn1000/ApplePayFinal)
- Square payment integration via Web SDK
- IBAN collection + logging in `logs/transactions.json`
- Serverless deployment structure with `vercel.json`
- `/api/pay.js` for Square transactions
- `/api/webhook.js` to receive Square events
- Cleaned up and rewritten `README.md` to reflect real app
- GitHub release tag `v1.0.0` for stable snapshot

### Folder Structure

