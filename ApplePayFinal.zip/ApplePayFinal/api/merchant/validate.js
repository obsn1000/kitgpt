import https from 'https';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'Missing validationURL in body' });

    const options = {
      hostname: 'apple-pay-gateway.apple.com',
      port: 443,
      path: '/paymentservices/startSession',
      method: 'POST',
      cert: fs.readFileSync(path.join(process.cwd(), 'certs/merchant_id.pem')),
      key: fs.readFileSync(path.join(process.cwd(), 'certs/merchant_id.key')),
      ca: fs.readFileSync(path.join(process.cwd(), 'certs/wwdr.pem')),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const postData = JSON.stringify({
      merchantIdentifier: 'merchant.ApplePayFinal',
      displayName: 'ReapWallet',
      initiative: 'web',
      initiativeContext: url
    });

    const request = https.request(options, (appleRes) => {
      let data = '';
      appleRes.on('data', chunk => (data += chunk));
      appleRes.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          res.status(200).json({ merchantSession: parsed });
        } catch (err) {
          res.status(500).json({ error: 'Invalid JSON returned by Apple', raw: data });
        }
      });
    });

    request.on('error', (err) => {
      res.status(500).json({ error: err.toString() });
    });

    request.write(postData);
    request.end();

  } catch (err) {
    res.status(500).json({ error: err.toString() });
  }
}
