import { Client } from 'square';
import fs from 'fs';
import path from 'path';

const client = new Client({
  accessToken: 'EAAAl-eS-waZbHAYthYPE3I1-yKMGuHwz4jdfIoUuX_HkfSA0x2UEZedF_eWr4ht',
  environment: 'sandbox',
});

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { nonce, iban } = req.body;
  const logFile = path.join(process.cwd(), 'logs', 'transactions.json');

  try {
    const idempotencyKey = `txn_${Date.now()}`;
    const response = await client.paymentsApi.createPayment({
      sourceId: nonce,
      amountMoney: { amount: 5000, currency: 'EUR' },
      idempotencyKey,
    });

    const entry = {
      time: new Date().toISOString(),
      transactionId: response.result.payment.id,
      iban,
    };

    let logs = [];
    if (fs.existsSync(logFile)) {
      logs = JSON.parse(fs.readFileSync(logFile));
    }
    logs.push(entry);
    fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));

    res.status(200).json({ success: true, transactionId: entry.transactionId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}