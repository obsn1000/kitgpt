import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import archiver from 'archiver';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default async function handler(req, res) {
  try {
    const tmpDir = '/tmp/reapwalletpass';
    const outputFile = '/tmp/reapwallet.pkpass';

    const passJson = {
      formatVersion: 1,
      passTypeIdentifier: "pass.ApplePayFinal",
      serialNumber: crypto.randomUUID(),
      teamIdentifier: "YN229FU2KK",
      organizationName: "Reapware",
      description: "ReapWallet K/BAN Wallet Pass",
      logoText: "ReapWallet",
      barcode: {
        message: "KBAN-001-XYZ",
        format: "PKBarcodeFormatQR",
        messageEncoding: "iso-8859-1"
      },
      generic: {
        primaryFields: [{
          key: "kban",
          label: "K/BAN",
          value: "KBAN-001-XYZ"
        }]
      }
    };

    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(path.join(tmpDir, 'pass.json'), JSON.stringify(passJson));

    // Sample icon
    const iconData = Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAABV7bNHAAAABmJLR0QA/wD/AP+gvaeTAAAA" +
      "CXBIWXMAAB7CAAAewgFu0HU+AAAAGHRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAJJJREFU" +
      "eNrs0TEBAAAAwqD1T20PBxQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
      "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4HPYAAeTPU4sAAAAASUVORK5CYII=",
      'base64'
    );
    fs.writeFileSync(path.join(tmpDir, 'icon.png'), iconData);
    fs.writeFileSync(path.join(tmpDir, 'logo.png'), iconData);

    // Manifest
    const manifest = {
      'pass.json': crypto.createHash('sha1').update(JSON.stringify(passJson)).digest('hex'),
      'icon.png': crypto.createHash('sha1').update(iconData).digest('hex'),
      'logo.png': crypto.createHash('sha1').update(iconData).digest('hex')
    };
    fs.writeFileSync(path.join(tmpDir, 'manifest.json'), JSON.stringify(manifest));

    // Signature
    const sign = crypto.createSign('RSA-SHA256');
    sign.update(JSON.stringify(manifest));
    const privateKey = fs.readFileSync(path.join(process.cwd(), 'certs/signingKey.pem'));
    const signature = sign.sign(privateKey);
    fs.writeFileSync(path.join(tmpDir, 'signature'), signature);

    // Zip into .pkpass
    const output = fs.createWriteStream(outputFile);
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.pipe(output);
    archive.directory(tmpDir, false);
    await archive.finalize();

    output.on('close', () => {
      res.setHeader('Content-Type', 'application/vnd.apple.pkpass');
      res.setHeader('Content-Disposition', 'attachment; filename=reapwallet.pkpass');
      fs.createReadStream(outputFile).pipe(res);
    });

  } catch (err) {
    console.error("PKPASS Error:", err);
    res.status(500).json({ error: err.toString() });
  }
}
