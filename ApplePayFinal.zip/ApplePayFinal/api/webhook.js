export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const event = req.body;

  console.log("🔔 Square Webhook Received:", JSON.stringify(event, null, 2));

  res.status(200).send('Webhook received');
}