import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  const passData = {
    serialNumber: "reap-pass-001",
    description: "Reapware Wallet Pass",
    formatVersion: 1,
    organizationName: "Reapware",
    passTypeIdentifier: "pass.cc.reapwareapi",
    teamIdentifier: "TEAMID1234",
    webServiceURL: "https://reapwareapi.cc/api/passes",
    authenticationToken: "auth-token-123",
    barcode: {
      message: "reapware-kban-001",
      format: "PKBarcodeFormatQR",
      messageEncoding: "iso-8859-1"
    }
  };

  fs.writeFileSync(path.join(process.cwd(), "public/pass.json"), JSON.stringify(passData));
  res.status(200).json({ success: true, passData });
}
