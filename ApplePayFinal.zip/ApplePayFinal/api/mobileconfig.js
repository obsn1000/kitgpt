import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  const mobileconfig = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadDisplayName</key>
  <string>ReapWallet Profile</string>
  <key>PayloadDescription</key>
  <string>Auto loads ReapWallet Wallet Pass</string>
  <key>PayloadIdentifier</key>
  <string>cc.reapwareapi.kbanprofile</string>
  <key>PayloadOrganization</key>
  <string>Reapware</string>
  <key>PayloadRemovalDisallowed</key>
  <false/>
  <key>PayloadType</key>
  <string>Configuration</string>
  <key>PayloadUUID</key>
  <string>8F33F83A-1A24-4E19-8D2F-REAPWALLET</string>
  <key>PayloadVersion</key>
  <integer>1</integer>
</dict>
</plist>`;
  res.setHeader('Content-Type', 'application/x-apple-aspen-config');
  res.setHeader('Content-Disposition', 'attachment; filename="reapwallet.mobileconfig"');
  res.send(mobileconfig);
}
