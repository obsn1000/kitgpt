# 🍎 ApplePayFinal – Unified Square + Wallet Payment System

This is a fully integrated Node.js + Square + Wallet project designed to handle:

- 💳 Secure Square payments
- 🏦 IBAN collection + logging
- 🌐 Apple Wallet (pass generation planned)
- 🧾 Square webhook listener
- 📱 iOS Reader SDK app support (optional)
- ⚙️ Vercel-ready deployment (serverless)

> This repo merges [`ApplePayFinal`](https://github.com/obsn1000/ApplePayFinal) and [`square`](https://github.com/obsn1000/square) for a unified experience.

---

## 🚀 Features

- Accept payments via Square (web or mobile)
- Collect and log IBAN numbers per transaction
- Supports deployment on [Vercel](https://vercel.com)
- Reader SDK-ready for in-person iOS payments
- Webhook endpoint for Square events
- Fully mergeable and expandable architecture

---

## 📂 Project Structure


